package com.example.safsouf.signalcollecte.modele;

import android.app.Service;
import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.widget.Toast;

import com.example.safsouf.signalcollecte.vue.Main2Activity;
import com.example.safsouf.signalcollecte.vue.MainActivity;

import java.util.List;

public class Debit   {




    }

